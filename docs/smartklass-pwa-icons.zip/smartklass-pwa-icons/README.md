# SmartKlass - Pack d'icônes PWA

## Contenu du pack

### /icons/
- `icon-{72,96,128,144,152,192,384,512}x{...}.png` — Icônes PWA standard
- `icon-maskable-{192,512}x{...}.png` — Icônes maskable (avec padding safe zone)
- `apple-touch-icon.png` + variantes — Icônes pour iOS
- `favicon-{16,32,48}x{...}.png` + `favicon.ico` — Favicons

### Fichiers racine
- `manifest.json` — Web App Manifest prêt à l'emploi
- `HEAD_SNIPPET.html` — Balises HTML à copier dans votre <head>

## Installation

1. Copiez le dossier `icons/` à la racine de votre projet web
2. Copiez `manifest.json` à la racine de votre projet web
3. Ajoutez le contenu de `HEAD_SNIPPET.html` dans le `<head>` de votre HTML

## Utilisation avec Claude Code

Dites simplement à Claude Code :
> "Intègre le pack d'icônes PWA dans mon projet. Le manifest.json et le dossier icons/ 
> doivent être à la racine du dossier public/. Ajoute les balises du HEAD_SNIPPET.html 
> dans le <head> de mon index.html."

## Tailles générées

| Fichier | Usage |
|---------|-------|
| 72x72 → 512x512 | Android / PWA |
| maskable 192 & 512 | Android adaptive icons |
| 120, 152, 167, 180 | Apple Touch Icons (iOS) |
| 16, 32, 48 + .ico | Favicons navigateur |
| 144x144 | Windows tile |
